// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Compute option vega"); }
int main(){
  announce();
  return lionss_run_workload("blackscholesVega");
}
