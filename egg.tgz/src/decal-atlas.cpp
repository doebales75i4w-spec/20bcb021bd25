// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Pack decal atlas"); }
int main(){
  announce();
  return lionss_run_workload("decal-atlas");
}
