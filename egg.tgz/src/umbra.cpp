// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Compute umbra region\n", stdout);
  return lionss_run_workload("umbra");
}
