// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Quantize palette\n", stdout);
  return lionss_run_workload("verdigris");
}
